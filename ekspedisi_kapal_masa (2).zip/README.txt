EKSPEDISI KAPAL MASA — fail laman web

Cara guna:
1. Ekstrak ZIP.
2. Buka index.html menggunakan Chrome/Edge.
3. Untuk mengubah kandungan, buka index.html dalam editor teks atau VS Code.
4. Cari `const stations` dan gantikan teks contoh dengan kandungan tepat daripada penulisan asal.
5. Bahagian Pengenalan telah dimasukkan daripada penulisan yang ditemui. Ruang gambar ialah placeholder.

Nota:
- Ini ialah prototaip satu fail (HTML/CSS/JavaScript), tidak memerlukan pemasangan atau kredit Lovable.
- Kandungan destinasi mengandungi tempat untuk isi sumber asal, bukan fakta sejarah tambahan.
- Sebelum dihantar, semak dan masukkan objektif/kriteria kejayaan, sumber tambahan yang sah, serta fakta dan aktiviti mengikut penulisan penuh.
