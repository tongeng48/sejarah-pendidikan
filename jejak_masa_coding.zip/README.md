# Jejak Masa — Coding Website
1. Extract ZIP.
2. Buka `index.html` dalam browser atau VS Code Live Server.
3. Untuk gambar profil, letakkan gambar dalam `assets` dan ubah `src` pada `index.html`.
Fail utama: index.html, style.css, script.js.
Nota: Sila semak fakta dan tambah butiran laporan/tokoh berdasarkan penulisan serta rubrik asal sebelum hantar.